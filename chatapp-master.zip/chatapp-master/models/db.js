module.exports = {
    conStr: 'mongodb://nolan_dakyung:admin123@ds213255.mlab.com:13255/nolan_dakyung'
  };
  
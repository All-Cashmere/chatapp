To start

npm start
